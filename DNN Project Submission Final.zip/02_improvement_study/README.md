# Part 2 · Improvement study: closing the gap to the paper

**Notebook:** `02_MLP_Validation_Paper_v3_improvement_study.ipynb` (originally `MLP_Validation_Paper_v3.ipynb`),
executed, outputs saved. Parts A and B are the Part 1 code, unchanged except `RUN_HYPERPARAMETER_GRID = False`;
Part C is the improvement study.

**Protocol for every step:** all 300 samples; the same 5 folds as Part 1 ("tuning folds"); every evaluation repeated
3 times with new seeds; keep a change only if its R² gain > max(0.003, spread before, spread after), otherwise undo it;
one change at a time; SEA and KER decided separately; validation folds never used for training, stopping or augmentation.

| Cell | Step (slide) | Result |
|---|---|---|
| C-setup | Shared machinery: training loop, cache, keep-or-undo rule (7) | |
| C0 | Step 0 · baseline, 3 repeats (8) | SEA 0.816 ± 0.004, KER 0.841 ± 0.001 |
| C1 | Check 1 · energy balance SEA·M/4 + KER = E0 (9) | samples 1-45 break it; kept in this notebook |
| E1 | Check 2 · 100 single 80/20 splits of the baseline (10) | 1 % of splits reach the paper |
| C2 | Step 1 · five unreported training choices (11) | **PyTorch-style weight decay kept** (SEA +0.011, KER +0.028); init, early stopping, z-score, cosine LR undone |
| C3 | Step 2 · KER on a log scale (12) | −0.053, undone |
| C4 | No new input variables (decision) (12) | not done |
| C5 | Step 3 · data augmentation, self-contained snippet: jitter, mixup, kNN, GP surrogate, physics-consistent (13-14) | no gain beyond noise, undone |
| C6 | Step 4 · coordinate-search re-tuning of 8 hyperparameters (15-16) | **SEA λ = 5e-4 kept** (+0.005) |
| C7 | Step 5 · ensemble of 5 networks (17) | +0.002 / +0.003, below threshold, undone |
| C8 | Final checks: a fresh test folds, b single splits, c Table 9 with SVM / RF, d summary (18-21) | fresh folds SEA 0.837, KER 0.865 |

**`results_v3/`**
| File | Content |
|---|---|
| `ledger.json` | Every tested change, its R² before / after, threshold and decision; final settings per output (slide 22) |
| `C5_variants.json`, `C5_sensitivity.json` | Augmentation variants and the longer-training check |
| `C6_tuning.json` | Every value tried in the re-tuning |
| `C8_fresh_folds.json`, `C8_single_split.json`, `C8_table9.json` | Final checks 1-3 |
| `C8_whatif.json` | Earlier what-if without samples 1-45 (superseded by `03_clean_data_final`) |
| `figures/` | Figures used in the slides |
| `cache.zip` | One JSON per evaluation, keyed by all its settings. Unzip into `results_v3/cache/` and the notebook re-runs in about 4 minutes instead of 5-6 hours |
