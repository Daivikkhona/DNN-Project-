# MLP surrogate models: validation on Zhang et al. (2025) and application to my blast dataset

**Daivik Kaushik Khona · BITS Pilani · ME G545 (Deep Neural Networks) · Final review**

This repository contains every notebook, result file and the final presentation behind my DNN project.
Before applying a multi-layer perceptron (MLP) surrogate to my own LS-DYNA blast simulations, I validated the
whole pipeline on a published benchmark with known answers:

> Zhang et al., *Composites Part B: Engineering* 307 (2025) 112961: steel / SiC / UHMWPE armour,
> 300 Latin-hypercube LS-DYNA samples, inputs t1, t2, t3 (layer thicknesses), outputs **SEA** (specific energy
> absorption, J/kg) and **KER** (residual kinetic energy of the projectile, J). Reported MLP accuracy: R² 0.901 (SEA), 0.950 (KER).

The work has three parts, and the folders are numbered in the order the work was done.

| Part | Folder | Question | Slides |
|---|---|---|---|
| 1 · Reproduction | [`01_paper_reproduction`](01_paper_reproduction) | Can I reproduce the paper's MLP? | 1-5 |
| 2 · Improvement study | [`02_improvement_study`](02_improvement_study) | Which justified changes close the gap to the paper? | 6-22, 25-26 |
| Final step · Clean data | [`03_clean_data_final`](03_clean_data_final) | How accurate is the same model on physically consistent data? | 23-24, 26 |
| 3 · Own data set | [`04_own_dataset`](04_own_dataset) | The same architecture on my 458-sample graded auxetic-core blast dataset | 27-29 |

---

## Results at a glance

**Paper dataset (300 samples, 5-fold cross-validation, mean of the 5 validation folds in physical units)**

| Stage | Where | SEA R² | KER R² |
|---|---|---|---|
| Paper (Zhang et al. 2025, one 80/20 split) | Table 9 of the paper | 0.901 | 0.950 |
| Mid-semester reproduction, one run | `01` · A5, A6 | 0.821 | 0.841 * |
| Step 0 · baseline, 3 repeats | `02` · C0 | 0.816 ± 0.004 | 0.841 ± 0.001 |
| Final model, tuning folds (after steps 1-5) | `02` · C2-C7 | 0.832 ± 0.002 | 0.869 ± 0.004 |
| Final model, fresh test folds (never used for a decision) | `02` · C8a | 0.837 ± 0.002 | 0.865 ± 0.001 |
| **Final model on the 255 energy-consistent samples** | `03` · D3 | **0.908 ± 0.003** (fresh folds 0.899) | 0.864 ± 0.004 (fresh folds 0.861) |

\* 0.844 in the original Colab run; 0.841 when re-measured on my PC (CPU arithmetic). ± is the standard deviation over 3 repeats with new seeds.

Only two of nine ideas survived the keep-or-undo rule: PyTorch-style weight decay (L2 added to the gradient) for both
outputs, and λ = 5e-4 for SEA. Removing the 45 samples that break energy conservation (samples 1-45, faulty in the
paper's own supplement) brings SEA to the paper's accuracy; KER stays below 0.950 and reaches it only on favourable
single 80/20 splits.

**Own dataset (458 samples, 23 inputs, 5-fold CV, mean of 5 folds)**

| Output | Code 1 · ReLU, 64-64-64 | Code 2 · Swish, 128-64-32 |
|---|---|---|
| MD, maximum deflection (mm) | R² 0.786 · MAE 2.19 mm | R² 0.776 · MAE 2.10 mm |
| RC, crushing force (kN) | R² 0.537 · MAE 19.36 kN | R² 0.616 · MAE 18.07 kN |
| SEA, specific energy absorption (J/kg) | R² 0.769 · MAE 25.19 J/kg | R² 0.822 · MAE 19.17 J/kg |

---

## Repository structure

```
DNN-Project-/
├── README.md                          this file
├── requirements.txt                   core packages (pinned)
├── requirements-lock.txt              full environment used for the local runs (pip freeze)
├── 01_paper_reproduction/             Part 1 · mid-semester reproduction of the paper
│   ├── 01_MLP_Validation_Paper_reproduction.ipynb
│   └── colab_output_hyperparameter_grid.txt
├── 02_improvement_study/              Part 2 · steps 0-5, checks 1-2, final checks 1-3
│   ├── 02_MLP_Validation_Paper_v3_improvement_study.ipynb
│   └── results_v3/                    ledger of every decision, result tables, figures, cache.zip
├── 03_clean_data_final/               Final step · same model on the 255 consistent samples
│   ├── 03_MLP_Validation_Paper_v4_clean_data.ipynb
│   └── results_v4_clean/              result tables, figures, cache.zip
├── 04_own_dataset/                    Part 3 · my 458-sample blast dataset
│   ├── 04a_ML_CRESH_Graded_core_ReLU.ipynb
│   ├── 04b_ML_CRESH_Graded_core2_Swish.ipynb
│   └── data/README.md                 expected format of gradeddata.csv (data not published)
├── docs/
│   └── EXPERIMENT_LOG.md              every setting, result and keep/undo decision
└── presentation/
    └── DNN_Final_Review_MLP_Validation.pptx   final deck (29 slides, speaker notes)
```

Each numbered folder has its own README with the cells, inputs, outputs and slides it covers.

---

## Slide-to-code map

Cell names (A0, C2, D3, ...) are the section headings inside the notebooks.

| Slide | Topic | Notebook | Cells |
|---|---|---|---|
| 1 | Title | | |
| 2 | Part 1 · What I reproduced | `01` | A0-A2 |
| 3 | Part 1 · Model (two networks) | `01` | A0, A3 |
| 4 | Part 1 · My reproduction (R² 0.821 / 0.841) | `01` (outputs re-run in `02`) | A5, A6 |
| 5 | Part 1 · Diagnosis (42-setting grid, ρ 0.36 / 0.51; data inconsistency) | `01` + `colab_output_hyperparameter_grid.txt`; `02`, `03` | A4; C1; D3 |
| 6 | Part 2 divider and glossary | | |
| 7 | Method: one change at a time, keep-or-undo rule | `02` | C-setup |
| 8 | Step 0 · Baseline | `02` | C0 |
| 9 | Check 1 · Data audit (energy balance) | `02` | C1 |
| 10 | Check 2 · Single-split evaluation | `02` | E1 |
| 11 | Step 1 · Training procedure (weight-decay form) | `02` | C2 |
| 12 | Step 2 · Log scale for KER (C4 not done) | `02` | C3, C4 |
| 13-14 | Step 3 · Data augmentation (separate snippet) | `02` | C5 |
| 15-16 | Step 4 · Re-tuning (coordinate search) | `02` | C6 |
| 17 | Step 5 · Ensemble | `02` | C7 |
| 18 | Final check 1 · Fresh test folds | `02` | C8 (C8a) |
| 19 | Final check 2 · Single splits of the final model | `02` | C8 (C8b) |
| 20 | Final check 3 · Paper's Table 9, SVM and RF | `02` | C8 (C8c), Part B |
| 21 | Summary of steps | `02` | C8 (C8d) |
| 22 | Every setting, baseline vs final | `02` | `results_v3/ledger.json` |
| 23 | Final step · Why the 45 samples are removed | `03` | D1 |
| 24 | Final step · Result on the clean data | `03` | D2-D6 |
| 25-26 | Course concepts, summary | `02`, `03` | all |
| 27 | Part 3 divider | | |
| 28 | Code 1 · ReLU network on my data | `04a` | all |
| 29 | Code 2 · Swish network on my data | `04b` | all |

Every number on the slides is in a notebook output or in a JSON file under `results_v3/` or `results_v4_clean/`;
[`docs/EXPERIMENT_LOG.md`](docs/EXPERIMENT_LOG.md) lists each one with its settings.

---

## How to run

The notebooks are saved **with their outputs**, so they can be read on GitHub without running anything.

```bash
python -m venv .venv
.venv\Scripts\activate          # Windows;  source .venv/bin/activate on Linux / macOS
pip install -r requirements.txt
jupyter lab
```

- Python 3.11.9, TensorFlow 2.21 / Keras 3.15, CPU only. `requirements-lock.txt` is the exact environment.
- **Open each notebook from its own folder**: results are read from and written to `results_v3/` or `results_v4_clean/` next to the notebook.
- The paper's 300 samples are **embedded in the notebooks** (Appendix A of the paper), so no data download is needed for Parts 1-2 and the final step. A CSV at `DATA_PATH` is used instead if it exists.
- `02` and `03` cache every evaluation as one JSON file each. The caches are stored as `results_v3/cache.zip` and `results_v4_clean/cache.zip`; **unzip each into a folder `cache/` next to it** before running. With the cache, `02` runs in about 4 minutes; without it (or with `FORCE_RERUN = True` in C-setup) everything is retrained, about 5-6 hours on an 8-core laptop CPU. TensorFlow op determinism is on, so the same seed gives bit-identical results.
- `01` is the mid-semester notebook exactly as run in Google Colab. Its A4 grid (`RUN_HYPERPARAMETER_GRID = True`) takes 30-60 min; its printed output is saved in `01_paper_reproduction/colab_output_hyperparameter_grid.txt`. Parts A and B are re-run, with outputs, at the top of `02`.
- `04a` / `04b` were run in Google Colab and read `/content/gradeddata.csv`; the dataset is not published here (see [`04_own_dataset/data/README.md`](04_own_dataset/data/README.md)).

---

## Original file names

The notebooks were renamed only to show the order of the work; their code and outputs are unchanged.

| Original name (as in the experiment log and slides) | In this repository |
|---|---|
| `MLP_Validation_Paper.ipynb` | `01_paper_reproduction/01_MLP_Validation_Paper_reproduction.ipynb` |
| `MLP_Validation_Paper_v3.ipynb`, `results_v3/` | `02_improvement_study/02_MLP_Validation_Paper_v3_improvement_study.ipynb`, `results_v3/` |
| `MLP_Validation_Paper_v4_clean.ipynb`, `results_v4_clean/` | `03_clean_data_final/03_MLP_Validation_Paper_v4_clean_data.ipynb`, `results_v4_clean/` |
| `ML_CRESH_Graded_core_(With_ReLU).ipynb` | `04_own_dataset/04a_ML_CRESH_Graded_core_ReLU.ipynb` |
| `ML_CRESH_Graded_core2_(With_sigmoid).ipynb` | `04_own_dataset/04b_ML_CRESH_Graded_core2_Swish.ipynb` (the code uses Keras `swish` = x·sigmoid(x), so the name was corrected) |

---

## Known limitations (also stated in the presentation)

- KER stays at 0.86-0.87 on 5-fold CV; it reaches 0.950 only on favourable single 80/20 splits (7 % of 100 splits).
- On the clean data a tuned SVM is even better for SEA (0.920) and ties the MLP on KER, so the paper's ranking MLP > SVM > RF is not reproduced.
- The gradient clip-norm (1.0) was never varied.
- Part 3 notebooks: one unseeded run per fold, Min-Max scaler fitted on all 458 rows before splitting, and Keras (decoupled) weight decay that is practically inactive at these settings. Code 2 changes the activation and the layer widths together, so its gain cannot be credited to Swish alone. None of the Part 2 findings has been applied to the own dataset yet.

## Reference

Zhang et al., *Composites Part B: Engineering* 307 (2025) 112961, including its supplementary data (Appendix A).
