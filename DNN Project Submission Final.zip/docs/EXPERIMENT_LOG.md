# Experiment log: closing the gap to Zhang et al. (2025)

Notebook: `02_improvement_study/02_MLP_Validation_Paper_v3_improvement_study.ipynb` (Part C; originally `MLP_Validation_Paper_v3.ipynb`). The mid-semester notebook `01_paper_reproduction/01_MLP_Validation_Paper_reproduction.ipynb` (originally `MLP_Validation_Paper.ipynb`) is unchanged.
Goal: move the MLP's 5-fold validation R² (Part A: SEA 0.821, KER 0.841) as close as possible to the paper (SEA 0.901, KER 0.950), using changes that can be justified, tested and explained.

## Protocol (applies to every step)
| Rule | Setting |
|---|---|
| Data | All 300 samples of Appendix A in every step (samples 1-45 are audited in C1, never removed from the pipeline) |
| Inputs / scaling | t1, t2, t3, Min-Max scaled on all 300 rows, exactly as Part A (no new input variables: C4 not done) |
| Validation | 5-fold CV, folds `KFold(5, shuffle=True, random_state=42)` = the same folds as Part A |
| Repeats | Every evaluation is repeated 3 times with different seeds (seed = 42 + fold + 100 × repeat); repeat 0 uses exactly Part A's seeds |
| Metric | Mean of the 5 validation folds, in physical units; reported as mean ± spread (standard deviation) over the 3 repeats |
| Keep / undo rule | Keep a change for a target only if `R² gain > max(0.003, spread before, spread after)`; otherwise undo it |
| Targets | SEA and KER decided separately (separate networks) |
| Order | One change at a time, each tested on top of the current best pipeline |
| Leakage guard | Validation folds are never used for training, early stopping, augmentation or any decision inside a fold |
| Final test | C8 re-scores the final pipeline on new folds (`random_state=2026`) that were never used for a decision |
| Determinism | `tf.config.experimental.enable_op_determinism()`: the same seed gives bit-identical results |

## Files
| File | Content |
|---|---|
| `02_improvement_study/02_MLP_Validation_Paper_v3_improvement_study.ipynb` | Parts A and B (unchanged except `RUN_HYPERPARAMETER_GRID = False` in A0) + Part C, executed, outputs saved |
| `02_improvement_study/results_v3/cache.zip` (unzip to `cache/*.json`) | Cached result of every evaluation, keyed by all its settings |
| `02_improvement_study/results_v3/ledger.json` | Every tested change, its result and the keep/undo decision; final settings per target |
| `02_improvement_study/results_v3/*.json` | Tables of C5 (variants, sensitivity), C6 (tuning), C8 (new folds, single splits, Table 9, what-if) |
| `02_improvement_study/results_v3/figures/*.png` | Figures used in the slides |
| `docs/EXPERIMENT_LOG.md` | This file |
| `03_clean_data_final/03_MLP_Validation_Paper_v4_clean_data.ipynb` | Final step: same final pipeline on the 255 energy-consistent samples (section D below) |
| `03_clean_data_final/results_v4_clean/` | Cache, tables and figures of the v4 notebook |
| `01_paper_reproduction/colab_output_hyperparameter_grid.txt` | Printed output of the 42-setting grid (A4) from the Colab run |
| `04_own_dataset/04a_…ReLU.ipynb`, `04b_…Swish.ipynb` | Part 3: the architecture on my 458-sample blast dataset (section E below) |
| `presentation/DNN_Final_Review_MLP_Validation.pptx` | Final presentation, 29 slides with speaker notes (1-5 reproduction, 6-22 improvement study, 23-24 final step, 25-26 concepts and summary, 27-29 own dataset); see "Final deck" at the end |

**Re-running:** with the cache present the whole notebook runs in about 4 minutes. With `FORCE_RERUN = True` (or without `results_v3/cache`) every model is retrained: about 5-6 hours on an 8-core laptop CPU.

## Environment
Python 3.11.9, TensorFlow 2.21.0 / Keras 3.15.1, scikit-learn 1.9.1, NumPy 2.4.6, pandas 3.1.1 (CPU, Windows; full list in `requirements-lock.txt` at the repository root). Running Part A locally reproduces the Colab numbers: SEA R² 0.8211 (Colab 0.8211), KER R² 0.8407 (Colab 0.8443; small difference from CPU arithmetic).

---

## Code changes outside Part C
| Where | Change | Why |
|---|---|---|
| A0 | `RUN_HYPERPARAMETER_GRID = True` → `False` | The 42-setting grid (A4) was already run in Colab; its output is in `01_paper_reproduction/colab_output_hyperparameter_grid.txt`. Saves 30-60 min per run |
| Top of notebook | New markdown cell "Version 3" describing these changes | Transparency |
| Everything else in Parts A and B | unchanged | |

## C0 · Baseline (Part A settings, 3 repeats)
**Settings (all of them):** inputs t1, t2, t3 Min-Max scaled · one network per target, linear output · SEA 128 × 3, KER 64 × 3 hidden units · dropout 0.2 after every hidden layer · learning rate SEA 2e-4, KER 4e-4 · weight decay SEA 1e-3, KER 5e-4 (Keras decoupled form) · ReLU · MSE loss · Adam, clip-norm 1.0 · Glorot-uniform weights, zero biases · batch size 12 · 300 epochs, no early stopping · Min-Max target scaling.

| Target | R² (mean ± spread, 3 repeats) | R² of each repeat | MAE | RMSE | Paper R² / MAE / RMSE |
|---|---|---|---|---|---|
| SEA | **0.8160 ± 0.0036** | 0.8211, 0.8130, 0.8139 | 48.59 J/kg | 75.53 J/kg | 0.901 / 35.53 / 56.62 |
| KER | **0.8413 ± 0.0010** | 0.8407, 0.8405, 0.8427 | 221.50 J | 375.80 J | 0.950 / 109.66 / 190.88 |

**Check:** repeat 0 uses Part A's seeds and reproduces A5/A6 fold by fold (SEA 0.8031, 0.8626, 0.7299, 0.8626, 0.8474; KER 0.9169, 0.8369, 0.7221, 0.8945, 0.8332) → the Part C training code trains exactly the same network as Part A.
**Context:** Part B on the same folds: SVM R² 0.832 (SEA) / 0.870 (KER), RF 0.811 / 0.825. The baseline MLP is beaten by the SVM on both targets.
**Concepts:** baseline model; seed-to-seed variance of a small network (initial weights, dropout masks, batch order).

## C1 · Data audit: energy balance (diagnostic only)
**What was checked:** SEA · M/4 + KER for every sample, with M/4 = quarter-plate mass from the paper's geometry (steel 480 × 480 mm, t1 + 10 mm back plate, 7800 kg/m³; SiC 300 × 300 mm, 3180 kg/m³; UHMWPE 480 × 480 mm, 1000 kg/m³). A least-squares fit of the plate-mass coefficients to the data recovers exactly these values.

| | Samples 1-45 | Samples 46-300 |
|---|---|---|
| SEA · M/4 + KER | 14,865 ± 859 J (13,210-16,235) | **16,259.00 ± 0.03 J** |
| Within 1 J of E0 = 16,259 J | 0 of 45 | 255 of 255 |
| Baseline mean abs. error, SEA | 126.2 J/kg | 33.9 J/kg (3.7× smaller) |
| Baseline mean abs. error, KER | 144.8 J | 239.2 J |

**Findings:** (1) the values of the notebook are identical to the official supplement `mmc1.docx`, so the inconsistency is in the published data; (2) on the 255 consistent samples the baseline's SEA error (33.9 J/kg) is already below the paper's MAE (35.53); (3) the faulty rows hurt SEA, not KER, so the inconsistency sits mainly in the SEA column.
**Decision:** no change. All 300 samples stay in the pipeline (the paper removes none). A clearly labelled what-if follows in C8d.
**Concept:** data-quality audit with a physical constraint.

## E1 · Paper-style evaluation of the baseline (one 80/20 split × 100 seeds)
**Protocol:** `train_test_split(test_size=0.2, random_state=s)` for s = 0…99; train on 240, score the other 60 (as in the paper's Figs. 13 and 15). Nothing is tuned on these splits.

| | SEA | KER |
|---|---|---|
| Mean R² | 0.824 | 0.846 |
| Median | 0.835 | 0.872 |
| 5th-95th percentile | 0.740-0.883 | 0.724-0.925 |
| Best split | 0.932 | 0.951 |
| Splits ≥ paper R² | 1 % | 1 % |

**Finding:** a single 60-sample validation set moves R² by about ±0.07, but only 1 % of splits reach the paper's values; the evaluation protocol alone does not explain the gap.
**Concept:** variance of a hold-out estimate; why k-fold CV is preferred on small datasets.

---

## C2 · Training procedure (choices the paper does not report)
Five changes, tested one at a time in this order, each on top of the pipeline as it stood after the previous test.

| # | Change | Exact setting | SEA R² (gain) | KER R² (gain) | Decision |
|---|---|---|---|---|---|
| a | Weight decay as coupled L2, as in `torch.optim.Adam(weight_decay=λ)` | `weight_decay_mode='coupled'`: gradient g ← clip(g) + λ·w before Adam; Keras' own decoupled decay switched off | 0.8274 ± 0.0015 (**+0.0114**) | 0.8689 ± 0.0036 (**+0.0276**) | **KEPT** for both |
| b | PyTorch default initialisation | `init='torch'`: W, b ~ U(−1/√fan_in, +1/√fan_in) | 0.8287 (+0.0012) | 0.8701 (+0.0012) | undone (gain < threshold 0.0030 / 0.0045) |
| c | Early stopping | `early_stopping=True`: 15 % of the training fold (36 rows) as inner validation, patience 30, max 1000 epochs, best epoch restored | 0.8190 (−0.0084) | 0.8501 (−0.0189) | undone |
| d | z-score target scaling | `target_scaling='zscore'` | 0.8281 (+0.0006) | 0.8544 (−0.0145) | undone |
| e | Learning-rate schedule | `lr_schedule='cosine'` (early stopping was not kept): lr_t = lr₀ · ½(1 + cos(π t / 300)) | 0.8294 (+0.0020) | 0.8669 (−0.0020) | undone |

**Pipeline after C2:** baseline + coupled L2 weight decay (both targets). SEA **0.8274 ± 0.0015** (MAE 51.23 J/kg, RMSE 73.19 J/kg); KER **0.8689 ± 0.0036** (MAE 165.88 J, RMSE 337.32 J).
**Interpretation:** the form of the weight decay is the only unreported choice that matters. With Adam, an L2 term added to the gradient is divided by Adam's running RMS of that weight's gradient, so it penalises weights with small gradients more strongly than decoupled decay does; the paper's PyTorch-style parameter names make this the more faithful choice. Early stopping costs 15 % of only 240 training rows, which outweighs its regularisation benefit here. Note for SEA: RMSE improved (75.53 → 73.19) while MAE rose slightly (48.59 → 51.23); decisions use R² (equivalent to MSE), as fixed in the protocol.
**Concepts:** L2 regularisation vs decoupled weight decay (AdamW); weight initialisation; early stopping; target standardisation; learning-rate scheduling.

---

## C3 · KER trained as log(1 + KER)
| Change | Exact setting | KER R² (gain) | MAE / RMSE | Decision |
|---|---|---|---|---|
| Train KER on a log scale | `target_transform='log1p'`: z = log(1 + KER), then Min-Max; prediction mapped back with exp(z) − 1 before any metric | 0.8158 ± 0.0270 (**−0.0531**) | 185.03 J / 406.69 J | undone |

**Why it fails:** the log scale splits KER into two separate clusters (stopped projectile, KER < 5 J, near 0.5; perforated between 4 and 8). The network must learn a jump between them, and a small error in log space near the top becomes hundreds of joules after exp(·). R² in joules is dominated by exactly those large values, and the seed spread grew from ±0.004 to ±0.027 (unstable).
**SEA:** not transformed (1175-2105 J/kg, not skewed).
**Pipeline after C3:** unchanged: SEA 0.8274 ± 0.0015, KER 0.8689 ± 0.0036.
**Concept:** target transformation for skewed outputs; the loss must be minimised on the scale the metric is measured on.

## C4 · New input features: not done (decision)
The network keeps exactly the paper's inputs t1, t2, t3. The plate mass computed from them is used only in the C1 audit and inside the C5 physics-consistent augmentation, never as a network input.

---

## C5 · Data augmentation (separate snippet: two cells in Part C5)
**Code:** cell 1 defines and registers five augmenters in `AUGMENTERS` (and shows synthetic rows of fold 1); cell 2 runs the experiments. The core pipeline calls an augmenter only when `cfg['augment']` is set. Code change in C-setup: a hook in `fit_predict` that appends the synthetic rows (with their loss weights) to the training rows of the fold; validation rows are never touched.

**Methods and exact settings**
| Method | Settings | Synthetic loss weight |
|---|---|---|
| Gaussian jitter | noise N(0, σ) on scaled inputs, σ = 0.01 or 0.02; output copied | 1 |
| Mixup (negative control) | random pairs, λ ~ Beta(0.4, 0.4), inputs and output blended | 1 |
| kNN interpolation | k = 5 nearest neighbours in scaled input space, within the same regime (KER < 5 J = stopped vs perforated), λ ~ U(0, 1) | 1 |
| GP surrogate | `GaussianProcessRegressor`, kernel Constant × Matern(ν = 2.5, length scales 0.3) + White noise, normalised targets, 2 optimiser restarts; KER fitted on log(1 + KER); new designs from a Latin hypercube in [0, 1]³ | 0.5 |
| Physics-consistent (SEA only) | kNN interpolation of (t1, t2, t3, KER); SEA = (E0 − KER)/(M/4), E0 = median energy balance of the training rows | 1 |

Sizes: +1× and +2× the training rows. Rule: epochs scaled down so every method has the same number of gradient steps (e.g. 150 epochs with +1×).

**Results (R² change vs the same pipeline without augmentation, 3 × 5-fold CV)**
| Variant | SEA | KER |
|---|---|---|
| jitter σ = 0.01, +1× | −0.0050 | +0.0039 |
| jitter σ = 0.02, +1× | −0.0053 | **+0.0044** (best; threshold 0.0053 → undone) |
| mixup α = 0.4, +1× | −0.0056 | −0.0008 |
| kNN, +1× | −0.0061 | +0.0015 |
| kNN, +2× | −0.0048 | −0.0039 |
| GP surrogate, +1× | −0.0073 | +0.0015 |
| GP surrogate, +2× | **−0.0014** (best → undone) | −0.0043 |
| physics-consistent, +1× | −0.0096 (but lowest MAE so far: 48.91 J/kg) | – |
| physics-consistent, +2× | −0.0140 (MAE 47.25 J/kg) | – |

**Sensitivity check (added after the first results):** the two best variants per target re-run with the full 300 epochs (so more updates), against a matched control without augmentation trained for the same number of updates.
| Target · variant | with augmentation, full epochs | control (no augmentation, same updates) | current pipeline | counts? |
|---|---|---|---|---|
| SEA · GP surrogate +2× | 0.8264 | 0.8275 (900 epochs) | 0.8274 | no |
| SEA · kNN +2× | 0.8240 | 0.8275 (900 epochs) | 0.8274 | no |
| KER · jitter σ = 0.02 +1× | 0.8703 | 0.8628 (600 epochs) | 0.8689 | no |
| KER · jitter σ = 0.01 +1× | 0.8695 | 0.8628 (600 epochs) | 0.8689 | no |

**Decision:** augmentation undone for both targets. Pipeline after C5 unchanged: SEA 0.8274 ± 0.0015, KER 0.8689 ± 0.0036.
**Interpretation:** (1) the 300 Latin-hypercube samples already cover the 3-input design space densely, so synthetic rows add little information; (2) trained twice as long without augmentation the KER network gets worse (0.869 → 0.863, consistent with overfitting; training scores were not recorded) while with jitter it stays at 0.870, i.e. input noise works as a regulariser, but it does not beat the 300-epoch pipeline; (3) physics-consistent rows lower SEA's MAE but raise its RMSE: they help typical samples and hurt the outliers (samples 1-45, which do not obey the energy balance). Augmentation is expected to matter more on the sparser 20-input, 458-sample blast dataset.
**Concepts:** data augmentation; noise injection as regularisation; vicinal risk minimisation (mixup, kNN); surrogate-model augmentation; physics-informed data generation; controlled comparison (matched control).

---

## C6 · Re-tuning (coordinate search, one dimension at a time)
Every value of a dimension scored with 3 × 5-fold CV on top of the current pipeline; the best value then had to pass the keep rule against the value in use. Order: activation → optimizer → width × depth → dropout → learning rate → weight decay → batch size → epochs (epochs added after C5, because 300 epochs was my own assumption).

| Dimension | Values tried | SEA (best alternative: R², gain → decision) | KER (best alternative: R², gain → decision) |
|---|---|---|---|
| Activation | relu, tanh, sigmoid, silu, elu | ReLU stays (tanh 0.790, sigmoid **−0.021**, SiLU 0.796, ELU 0.791) | ReLU stays (tanh 0.734, sigmoid **−0.046**, SiLU 0.799, ELU 0.769) |
| Optimizer | Adam, SGD + momentum 0.9 with lr × 10, RMSprop | Adam stays (RMSprop 0.827, SGD 0.822) | Adam stays (RMSprop 0.869, SGD 0.841) |
| Width × depth | 64/128/256 × 2/3/4 | 128 × 2: 0.8291 (+0.0017) → undone | 128 × 2: 0.8706 (+0.0016) → undone |
| Dropout | 0, 0.1, 0.2, 0.3 | 0.1: 0.8285 (+0.0011) → undone | 0.3: 0.8691 (+0.0001) → undone |
| Learning rate | 0.5×, 1×, 2×, 4× | 0.5× (1e-4): 0.8291 (+0.0017) → undone | 4e-4 stays |
| Weight decay λ | 0, 1e-4, 5e-4, 1e-3, 1e-2 | **5e-4: 0.8321 ± 0.0022 (+0.0047) → KEPT** (0: 0.816, 1e-2: 0.767) | 5e-4 stays (0: 0.839, 1e-2: 0.807) |
| Batch size | 8, 12, 32 | 12 stays (8: 0.832, 32: 0.830) | 12 stays (8: 0.863, 32: 0.868) |
| Epochs | 150, 300, 600, 900 | 300 stays (150: 0.828, 600: 0.830, 900: 0.831) | 300 stays (150: 0.864, 600: 0.863, 900: 0.868) |

**Pipeline after C6:** SEA: coupled L2 with λ = 5e-4 (paper: 1e-3), everything else as the paper → **0.8321 ± 0.0022** (MAE 49.51 J/kg, RMSE 72.12 J/kg). KER: unchanged → 0.8689 ± 0.0036.
**Interpretation:** (1) the paper's architecture, dropout, learning rate and batch size are already at the optimum of this pipeline: no alternative beats the setting in use by more than 0.002 R²; (2) the only kept change is a *smaller* weight decay for SEA, consistent with C2: the coupled L2 form regularises more strongly at the same λ, so the best λ moves down; (3) regularisation strength matters most: λ = 0 (SEA 0.816, KER 0.839) and λ = 1e-2 (0.767, 0.807) are both clearly worse than a moderate λ, consistent with over- and under-fitting (training scores were not recorded). λ = 0 also matches the Keras-style baseline (0.816 / 0.841): at η = 2e-4 and λ = 1e-3 the decoupled decay shrinks the weights by only about 0.1 % over 6,000 updates, so it was practically no regularisation; (4) sigmoid hidden units fail completely (R² ≈ 0: the network predicts the mean) because they saturate and their gradients vanish, which ReLU avoids; (5) SGD with momentum trails the adaptive optimizers at the same budget.
**Concepts:** activation functions and vanishing gradients; adaptive vs non-adaptive optimizers; model capacity / bias-variance; dropout and weight-decay regularisation; learning rate; mini-batch size; training length (under- vs over-fitting).

---

## C7 · Ensemble of 5 networks
| Change | Exact setting | SEA R² (gain) | KER R² (gain) | Decision |
|---|---|---|---|---|
| Average 5 networks | `ensemble=5`: identical settings, seeds s, s + 1000, …, s + 4000; predictions averaged in physical units | 0.8338 ± **0.0007** (+0.0017, threshold 0.0030) | 0.8721 ± **0.0010** (+0.0032, threshold 0.0036) | undone (both) |

**Interpretation:** the ensemble cut the seed-to-seed spread by a factor of 3-4 (SEA ±0.0022 → ±0.0007, KER ±0.0036 → ±0.0010): averaging removes the *variance* part of the error, as expected. The mean gain is small because most of the remaining error is *systematic* (bias), for example on samples 1-45, which more networks cannot remove. Not worth 5× the training cost here.
**Final pipeline (after C2-C7):**
- **SEA:** paper hyperparameters (128 × 3, dropout 0.2, lr 2e-4, batch 12, 300 epochs, ReLU, Adam, clip-norm 1.0, Glorot init, Min-Max) with weight decay as **coupled L2** and **λ = 5e-4** (paper 1e-3) → **R² 0.8321 ± 0.0022**, MAE 49.51 J/kg, RMSE 72.12 J/kg.
- **KER:** paper hyperparameters (64 × 3, dropout 0.2, lr 4e-4, λ = 5e-4, batch 12, 300 epochs, ReLU, Adam, clip-norm 1.0, Glorot init, Min-Max) with weight decay as **coupled L2** → **R² 0.8689 ± 0.0036**, MAE 165.88 J, RMSE 337.32 J.
**Concepts:** ensembling / model averaging; bias-variance decomposition of the error.

---

## C8 · Final checks (nothing changed or tuned)
### C8a · New folds (`random_state=2026`, never used for any decision)
| | SEA R² | SEA MAE / RMSE (J/kg) | KER R² | KER MAE / RMSE (J) |
|---|---|---|---|---|
| Baseline, decision folds (42) | 0.8160 ± 0.0036 | 48.6 / 75.5 | 0.8413 ± 0.0010 | 221.5 / 375.8 |
| Final, decision folds (42) | 0.8321 ± 0.0022 | 49.5 / 72.1 | 0.8689 ± 0.0036 | 165.9 / 337.3 |
| Baseline, new folds (2026) | 0.8286 ± 0.0023 | 48.0 / 74.4 | 0.8531 ± 0.0022 | 214.4 / 369.0 |
| **Final, new folds (2026)** | **0.8370 ± 0.0024** | 49.8 / 72.6 | **0.8652 ± 0.0014** | 163.8 / 355.3 |
| Paper (Table 9) | 0.901 | 35.5 / 56.6 | 0.950 | 109.7 / 190.9 |

Improvement over the baseline: SEA +0.016 on the decision folds, **+0.008 on new folds**; KER +0.028 on the decision folds, **+0.012 on new folds**. The gain survives new folds, at about half the size: the decision-fold numbers carry some selection bias, as expected after ~95 compared configurations. **The new-fold numbers are the honest final result.**

### C8b · Paper-style evaluation (E2): same 100 single 80/20 splits as E1
| | SEA mean | median | 5-95 % | best | splits ≥ 0.901 | KER mean | median | 5-95 % | best | splits ≥ 0.950 |
|---|---|---|---|---|---|---|---|---|---|---|
| E1 baseline | 0.824 | 0.835 | 0.740-0.883 | 0.932 | 1 % | 0.846 | 0.872 | 0.724-0.925 | 0.951 | 1 % |
| E2 final | 0.836 | 0.843 | 0.752-0.890 | 0.924 | 2 % | 0.869 | 0.884 | 0.751-0.956 | **0.968** | **7 %** |
| E2 final, epoch picked on the 60 scored samples (**invalid**, illustration) | 0.847 | 0.853 | 0.767-0.899 | 0.939 | 5 % | 0.883 | 0.896 | 0.773-0.966 | 0.978 | 14 % |

The invalid variant uses the same training (300 epochs) but keeps the epoch with the best score on the samples that are then scored (`early_stopping=True, es_on='test', max_epochs = patience = 300`). It adds about +0.01 to +0.015 R² and doubles the share of splits that reach the paper: re-using the validation set inflates a score.

### C8c · Table 9 revisited (decision folds, all 300 samples)
| Model | SEA R² (paper) | SEA MAE (paper) | KER R² (paper) | KER MAE (paper) |
|---|---|---|---|---|
| MLP baseline (C0) | 0.816 (0.901) | 48.6 (35.5) | 0.841 (0.950) | 221.5 (109.7) |
| **MLP final (Part C)** | **0.832** (0.901) | 49.5 (35.5) | **0.869** (0.950) | 165.9 (109.7) |
| SVM (Part B) | 0.832 (0.87) | 51.2 (44.3) | 0.870 (0.92) | 129.4 (148.3) |
| RF (Part B) | 0.811 (0.84) | 51.8 (51.8) | 0.825 (0.91) | 207.9 (158.8) |

The final MLP now ties the SVM (SEA 0.832 = 0.832; KER 0.869 vs 0.870) and beats the RF; the baseline MLP was behind the SVM on both. The paper's ranking MLP > SVM > RF is reproduced for MLP and SVM vs RF, but MLP and SVM are level here. Parity plots and loss curves: `results_v3/figures/C8c_parity.png`, `C8c_loss_curves.png` (all folds run the full 300 epochs).

### C8d · Ablation summary and what-if
Settings that differ from the baseline: **SEA** weight-decay form decoupled → coupled, λ 1e-3 → 5e-4; **KER** weight-decay form decoupled → coupled. Ledger of all 23 decisions: `results_v3/ledger.json`; chart: `results_v3/figures/C8d_ablation.png`.

**What-if (NOT part of the pipeline): the same pipelines on the 255 samples that satisfy the energy balance (samples 46-300), 3 × 5-fold CV**
| | All 300 samples | Samples 46-300 only | Paper |
|---|---|---|---|
| SEA baseline | 0.816 | 0.900 | 0.901 |
| **SEA final** | 0.832 | **0.906** (MAE 28.0, RMSE 47.4 J/kg) | 0.901 (MAE 35.5, RMSE 56.6) |
| KER baseline | 0.841 | 0.823 | 0.950 |
| KER final | 0.869 | 0.864 | 0.950 |

**Interpretation:** for SEA, the 45 rows that break the energy balance explain the whole gap: without them the final pipeline beats the paper on R², MAE and RMSE. For KER they do not (the inconsistency sits in the SEA column); the KER gap comes from the evaluation protocol: single 60-sample splits reach up to 0.968 and 7 % of them reach ≥ 0.950.

---

## Final summary
| | SEA R² | KER R² |
|---|---|---|
| Mid-semester (Part A, one run) | 0.821 | 0.841 |
| Baseline, 3 repeats, decision folds | 0.816 ± 0.004 | 0.841 ± 0.001 |
| **Final pipeline, new folds (honest final number)** | **0.837 ± 0.002** | **0.865 ± 0.001** |
| Final pipeline, paper-style single splits: mean / best | 0.836 / 0.924 | 0.869 / 0.968 |
| What-if in v3: final pipeline without the 45 faulty samples (scalers fitted on 300) | 0.906 | 0.864 |
| **Final step, v4: same model on the 255 clean samples (scalers fitted on 255)** | **0.908** | **0.864** |
| Paper | 0.901 | 0.950 |

**Kept:** weight decay as PyTorch-style coupled L2 (both targets); λ = 5e-4 for SEA. **Undone (within noise or worse):** PyTorch initialisation, early stopping, z-score targets, cosine schedule, log(1 + KER), all 16 augmentation variants (and the full-epoch sensitivity check), every other hyperparameter in C6, the 5-network ensemble. **Not done by decision:** removing samples, new input variables (C4).

**What carries over to the 458-sample blast dataset:** audit the data against physics first; keep the strict protocol (3 × 5-fold, keep rule, new-fold test); use coupled L2 and re-tune λ; re-test augmentation there (20 inputs, 458 samples: much sparser); compare against a tuned SVM as a strong baseline.

---

## D · Final step: clean data (separate notebook `03_clean_data_final/03_MLP_Validation_Paper_v4_clean_data.ipynb`)
**Why a separate notebook:** v3 keeps all 300 samples on purpose, because the paper does. v4 answers the remaining question: how accurate is the same MLP on physically consistent data? Nothing in v3 is changed.

**Structure:** A0, A1, A2, A3 copied unchanged from the original notebook; D1 (cleaning) inserted before the scaling; the v3 Part C machinery (unchanged, results in `results_v4_clean/`); D2-D6 new.

**D1 · Cleaning rule (fixed before any training):** keep a sample only if |SEA · M/4 + KER − E0| < 1 J, with E0 = median balance of all 300 samples = 16,258.99 J and M/4 the quarter-plate mass from the paper's geometry.
| | Count | Deviation from E0 |
|---|---|---|
| kept | 255 | at most 0.071 J |
| removed | 45 (exactly samples 1-45) | 24 to 3,049 J |

Any threshold between 0.07 J and 24 J removes exactly the same samples. After cleaning, the Min-Max scalers are fitted on the 255 rows; one 5-fold split is 204 training / 51 validation samples.

**D2 · Pipelines (nothing re-tuned):** `BASE` = paper settings (C0 of v3); `FINAL` = final pipeline of v3 (coupled L2 for both targets, λ = 5e-4 for SEA).

**D3 · 5-fold CV × 3 repeats on the clean data**
| Target | Pipeline | R² folds 42 | R² new folds 2026 | MAE | RMSE | Paper R² / MAE / RMSE |
|---|---|---|---|---|---|---|
| SEA | paper settings | 0.8967 ± 0.0024 | 0.8875 | 31.3 J/kg | 49.7 J/kg | 0.901 / 35.53 / 56.62 |
| SEA | **final pipeline** | **0.9075 ± 0.0028** | **0.8985** | **26.9 J/kg** | **46.8 J/kg** | 0.901 / 35.53 / 56.62 |
| KER | paper settings | 0.8263 ± 0.0102 | 0.8506 | 257.2 J | 398.4 J | 0.950 / 109.66 / 190.88 |
| KER | **final pipeline** | **0.8635 ± 0.0036** | **0.8608** | 189.5 J | 355.7 J | 0.950 / 109.66 / 190.88 |

**D4 · Paper-style single 80/20 splits × 100 (final pipeline, clean data):** SEA mean 0.906, median 0.916, 5-95 % 0.798-0.972, best 0.983, **60 % of splits ≥ 0.901**; KER mean 0.855, median 0.868, 5-95 % 0.724-0.950, best 0.984, 5 % of splits ≥ 0.950.

**D5 · SVM / RF on the clean data (nested CV, same as Part B):** SEA: SVM 0.920 (MAE 16.8), RF 0.892; KER: SVM 0.864, RF 0.824.

**D6 · Conclusion:**
- **SEA reproduces the paper on clean data:** R² 0.908 vs 0.901, MAE 26.9 vs 35.5 J/kg, RMSE 46.8 vs 56.6 J/kg (new folds 0.899; single splits median 0.916).
- **KER does not change** (0.864 vs 0.869 on all data): the inconsistency sits in the SEA column. Its gap to 0.950 is the paper's single-split evaluation.
- **Honest note:** on clean data the SVM is even better for SEA (0.920) and ties the MLP on KER, so the paper's claim that the MLP is the best of the three is not reproduced; the MLP and the SVM both reach the paper's SEA accuracy.
- Small difference from the v3 what-if (SEA 0.906): there the scalers were fitted on all 300 samples, here on the 255 clean ones.

**Slides:** 23 (why the 45 samples must be removed), 24 (final accuracy on the clean data), 26 (the whole study in one table).

---

## E · Part 3: the architecture on my own dataset (`04_own_dataset/`)
Two Colab notebooks apply the same Keras MLP pipeline to my 458 LS-DYNA blast simulations (23 inputs → MD, RC, SEA; one
network per output; Min-Max scaling; dropout 0.2; Adam, lr 4e-4, clip-norm 1.0, Keras weight decay 5e-4; batch 32,
175 epochs; 5-fold CV with random_state 42). They differ only in the hidden layers.

| Output | `04a` ReLU, 64-64-64 | `04b` Swish, 128-64-32 | `04b` better on |
|---|---|---|---|
| MD (mm) | R² 0.786, MAE 2.19 | R² 0.776, MAE 2.10 | 2 of 5 folds |
| RC (kN) | R² 0.537, MAE 19.36 | R² 0.616, MAE 18.07 | 5 of 5 folds |
| SEA (J/kg) | R² 0.769, MAE 25.19 | R² 0.822, MAE 19.17 | 3 of 5 folds |

Caveats: one unseeded run per fold; scaler fitted on all 458 rows before splitting; Keras weight decay shrinks the weights
by only about 0.04 % over 2,100 updates; `04b` changes activation and widths together (on the paper data SiLU = Swish lost
to ReLU in C6). The Part 2 findings are not applied to these notebooks yet. Slides 27-29.

---

## Final deck (`presentation/DNN_Final_Review_MLP_Validation.pptx`, 29 slides)
- Built on the BITS Pilani seminar template, with Morph transitions; the content and speaker notes are those of the
  review deck checked against the notebooks.
- Slides 1-5: Part 1, the mid-semester reproduction; slide 4 numbers re-measured locally (KER R² 0.841, MAE 47.8 J/kg
  and 225 J; Colab value 0.844 noted); slide 5 rank agreement from the actual grid run (ρ 0.36 / 0.51).
- Slides 6-26: Part 2 and the final step, with plain-language labels (Step 0-5, Check 1-2, Final check 1-3, Final step)
  and the notebook cell on each slide; a glossary on slide 6; summary on slide 26.
- Slides 27-29: Part 3, one slide per own-dataset notebook (settings, DNN concepts, results, caveats).
- Every number is generated from the notebook results.
**Concept:** data quality and label noise: removing samples that violate a physical law, using a rule fixed before training and independent of model errors.
