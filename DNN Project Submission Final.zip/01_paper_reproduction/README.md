# Part 1 · Reproduction of Zhang et al. (2025) (mid-semester)

**Notebook:** `01_MLP_Validation_Paper_reproduction.ipynb` (originally `MLP_Validation_Paper.ipynb`), the mid-semester
code exactly as run in Google Colab. It was saved without outputs; Parts A and B are re-run, unchanged and with outputs,
at the top of [`../02_improvement_study`](../02_improvement_study).

| Cell | What it does |
|---|---|
| A0 | Settings: seed 42, paper's best rows of Tables 7-8, `RUN_HYPERPARAMETER_GRID` |
| A1 | Loads the 300-sample dataset (embedded from the paper's Appendix A; a CSV at `DATA_PATH` is used if present) |
| A2 | Min-Max scaling of t1, t2, t3 and of each output; 5-fold split `KFold(5, shuffle=True, random_state=42)` |
| A3 | Keras MLP (ReLU hidden layers, dropout, linear output), Adam with clip-norm 1.0, MSE loss, 5-fold CV driver, metrics in physical units |
| A4 | Re-runs all 42 settings of the paper's Tables 7-8 (21 per output), 5-fold each, and the Spearman rank agreement with the paper |
| A5, A6 | SEA network (3 → 128 → 128 → 128 → 1) and KER network (3 → 64 → 64 → 64 → 1): validation metrics and parity plots |
| A7 | Final models trained on all data and predictions for new inputs |
| B1-B5 | SVM and Random Forest with nested CV; the paper's Table 9 vs the reproduction |

**`colab_output_hyperparameter_grid.txt`:** the printed output of A4 from the Colab run (both tables, paper vs reproduced
MAE / RMSE / R² / rank). Spearman ρ = 0.357 (SEA) and 0.513 (KER); used on slide 5.

**Result:** SEA R² 0.821 (paper 0.901), KER R² 0.844 in Colab, 0.841 re-measured locally (paper 0.950). Slides 2-5.
