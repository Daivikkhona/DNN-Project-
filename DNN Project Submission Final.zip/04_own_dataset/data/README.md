# Own dataset (not included)

The 458 LS-DYNA simulations of the graded auxetic-core panel are in-house data and are not published in this repository.

The notebooks in `04_own_dataset` expect `gradeddata.csv` with 458 rows and 26 numeric columns, in this order:

| Columns | Meaning |
|---|---|
| 1-23: `h1 h2 h3 l1 l2 l3 t1 t2 t3 tp1 tp2 beta1 beta2 beta3 r1 r2 r3 theta1 theta2 theta3 A1 A2 A3` | grading inputs of the three core layers |
| 24: `MD (mm)` | maximum deflection |
| 25: `RC(KN)` | crushing force |
| 26: `SEA (J/Kg)` | specific energy absorption |

The notebooks read it from `/content/gradeddata.csv` (Google Colab). To run locally, change that path in the first cell.
