# Part 3 · The architecture on my own dataset (458 blast simulations)

Two notebooks that apply the validated Keras MLP pipeline to my 458 LS-DYNA blast simulations of the graded
auxetic-core sandwich panel. They are identical except for the hidden layers. Both were run in Google Colab with outputs saved.

| | `04a_ML_CRESH_Graded_core_ReLU.ipynb` (slide 28) | `04b_ML_CRESH_Graded_core2_Swish.ipynb` (slide 29) |
|---|---|---|
| Original name | `ML_CRESH_Graded_core_(With_ReLU).ipynb` | `ML_CRESH_Graded_core2_(With_sigmoid).ipynb` |
| Hidden layers | 3 × 64 neurons (23-64-64-64-1), 9,921 weights | 128 → 64 → 32 (23-128-64-32-1), 13,441 weights |
| Activation | ReLU | Swish = x·sigmoid(x) (Keras `swish`, not plain sigmoid) |

**Shared settings:** 23 inputs → MD, RC, SEA; Min-Max scaling to [0, 1]; one network per output; dropout 0.2 after each
hidden layer; MSE loss; Adam, learning rate 4×10⁻⁴, clip-norm 1.0, weight decay 5×10⁻⁴ (Keras form); batch 32,
175 epochs, no early stopping; Glorot-uniform initialisation; 5-fold CV `KFold(5, shuffle=True, random_state=42)`;
R² and MAE after converting back to physical units, mean of the 5 folds.

| Output | Code 1 · ReLU | Code 2 · Swish | Code 2 better on |
|---|---|---|---|
| MD (mm) | R² 0.786 (folds 0.711-0.829) · MAE 2.19 | R² 0.776 (0.720-0.808) · MAE 2.10 | 2 of 5 folds |
| RC (kN) | R² 0.537 (0.405-0.580) · MAE 19.36 | R² 0.616 (0.532-0.736) · MAE 18.07 | 5 of 5 folds |
| SEA (J/kg) | R² 0.769 (0.687-0.826) · MAE 25.19 | R² 0.822 (0.792-0.904) · MAE 19.17 | 3 of 5 folds |

**Read with care**
- One run per fold and TensorFlow is not seeded, so a re-run gives slightly different scores.
- The scaler is fitted on all 458 rows before the split (a small test-fold leak into the scaling).
- Keras weight decay shrinks the weights by only about 0.04 % over the 2,100 updates, so it is practically off (the same finding as Step 1 of Part 2).
- Code 2 changes the activation and the layer widths together, so the gain cannot be credited to Swish alone. On the paper data, SiLU (= Swish) lost to ReLU in Step 4 (SEA 0.796 vs 0.827, KER 0.799 vs 0.869).
- `torch` is imported only for `torch.manual_seed`; the models are Keras.

**Running:** open in Google Colab, upload `gradeddata.csv` to `/content/` (format in [`data/README.md`](data/README.md)), run all cells.
