# Final step · The same model on the 255 energy-consistent samples

**Notebook:** `03_MLP_Validation_Paper_v4_clean_data.ipynb` (originally `MLP_Validation_Paper_v4_clean.ipynb`),
executed, outputs saved. A separate notebook, so that Part 2 keeps all 300 samples exactly as the paper does.

**Why samples are removed:** the paper defines SEA = (KE_I − KE_R)/M (Eq. 16). Every simulation uses the same projectile
and impact speed, so SEA·M/4 + KER must equal the impact energy E0 = 16,259 J for every sample (quarter model). The 255
samples 46-300 agree within 0.07 J; samples 1-45 miss by 24 to 3,049 J, and the paper's supplement has the same values.

| Cell | What it does (slides 19-20) |
|---|---|
| A0, A1 | Settings and data, copied unchanged from Part 1 |
| D1 | Cleaning rule fixed before any training: keep a sample only if \|SEA·M/4 + KER − E0\| < 1 J → removes exactly samples 1-45 (any threshold from 0.07 J to 24 J gives the same result) |
| A2, A3 | Scaling, 5-fold split and MLP, copied unchanged (scalers now fitted on the 255 samples) |
| C-setup | Part 2 machinery, unchanged; results go to `results_v4_clean/` |
| D2 | The two pipelines, fixed in advance: paper settings and the Part 2 final model (nothing re-tuned) |
| D3 | 5-fold CV × 3 repeats on the tuning folds and on fresh folds |
| D4 | 100 single 80/20 splits, as in the paper |
| D5 | SVM and Random Forest on the same clean data (nested CV) |
| D6 | Final accuracy vs the paper |

**Result (final model):** SEA R² 0.908 ± 0.003 (fresh folds 0.899; paper 0.901), MAE 26.9 J/kg; KER R² 0.864 ± 0.004
(fresh folds 0.861; paper 0.950). On single splits SEA reaches 0.901 in 60 % of splits, KER reaches 0.950 in 5 %.
SVM on the same data: SEA 0.920, KER 0.864.

**`results_v4_clean/`:** `D3_clean_cv.json`, `D4_clean_single_split.json`, `D6_table9_clean.json`, `figures/`, and
`cache.zip` (unzip into `results_v4_clean/cache/` to re-run from the cache).
